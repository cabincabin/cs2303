README File for PA3_cjdembski_fjvanrossum CS2303 Assignment



Sources:
1. http://www.geeksforgeeks.org/binary-tree-set-1-introduction/
2. http://cslibrary.stanford.edu/110/BinaryTrees.html
